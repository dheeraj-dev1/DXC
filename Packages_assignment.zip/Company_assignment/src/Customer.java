
public class Customer {
	public void productx() {
		System.out.println("customer says x is the best product");
	}

}
