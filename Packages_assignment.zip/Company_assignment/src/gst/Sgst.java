package gst;

public class Sgst {
	
	public void statetax() {
		System.out.println("state tax is deducted");
	}

}
