package gst;

public class Cgst {
	public void centraltax() {
		System.out.println("Central tax is deducted");
	}

}
