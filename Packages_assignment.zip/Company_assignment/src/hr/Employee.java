package hr;

public class Employee {
	public void person() {
		System.out.println("y is the employee");
	}

}
