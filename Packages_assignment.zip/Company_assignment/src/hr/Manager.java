package hr;

public class Manager {
	public void head() {
		System.out.println("z is the manager");
	}

}
