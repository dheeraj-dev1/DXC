import finance.Hra;
import finance.Pf;
import finance.Salary;
import gst.Cgst;
import gst.Sgst;
import hr.Employee;
import hr.Manager;

public class Client {

	public static void main(String[] args) {
		
		Customer c = new Customer();
		c.productx();
		
		Hra h = new Hra();
		h.rentallowance();
		
		Pf p = new Pf();
		p.providentfund();
		
		Salary s = new Salary();
		s.money();
		
		Cgst cg = new Cgst();
		cg.centraltax();
		
		Sgst sg =new Sgst();
		sg.statetax();
		
		Employee e = new Employee();
		e.person();
		
		Manager m = new Manager();
		m.head();
		
		
		
		
		

	}

}
