package finance;

public class Salary {
	public void money() {
		System.out.println("25000 is credited in your acc ! ");
	}

}
