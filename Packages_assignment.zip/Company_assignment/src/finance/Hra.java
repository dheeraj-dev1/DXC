package finance;

public class Hra {
	public void rentallowance() {
		System.out.println("House rent Allowance is available");
	}

}
