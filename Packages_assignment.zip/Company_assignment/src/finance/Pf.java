package finance;

public class Pf {
	public void providentfund() {
		System.out.println("provident fund is deducted from salary");
	}

}
